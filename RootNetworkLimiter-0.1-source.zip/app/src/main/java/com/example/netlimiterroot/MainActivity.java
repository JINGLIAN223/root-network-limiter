package com.example.netlimiterroot;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.io.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    EditText down, up;
    TextView status, log;
    Button apply, stop, check;
    ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 32, 28, 24);
        root.setBackgroundColor(Color.rgb(18, 22, 29));
        TextView title = new TextView(this); title.setText("Root 网络限速"); title.setTextSize(26); title.setTextColor(Color.WHITE);
        root.addView(title);
        TextView sub = new TextView(this); sub.setText("Wi-Fi · 需要 KernelSU Root 与内核 tc 支持"); sub.setTextColor(Color.LTGRAY); sub.setPadding(0,8,0,22); root.addView(sub);
        down = field("下载上限（Mbps，例如 20）"); root.addView(down);
        up = field("上传上限（Mbps，例如 5）"); root.addView(up);
        down.setText("20"); up.setText("5");
        status = new TextView(this); status.setText("状态：尚未检查"); status.setTextColor(Color.rgb(140,220,160)); status.setPadding(0,18,0,12); root.addView(status);
        check = button("检查 Root / tc / Wi-Fi 接口"); root.addView(check);
        apply = button("应用限速"); root.addView(apply);
        stop = button("清除限速"); root.addView(stop);
        log = new TextView(this); log.setTextColor(Color.LTGRAY); log.setTextSize(12); log.setTextIsSelectable(true); log.setPadding(0,18,0,0);
        ScrollView sv = new ScrollView(this); sv.addView(log); root.addView(sv, new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
        check.setOnClickListener(v -> runAsync("check"));
        apply.setOnClickListener(v -> {
            String d=down.getText().toString().trim(), u=up.getText().toString().trim();
            if (!valid(d) || !valid(u)) { status.setText("请输入 1–1000 的整数 Mbps"); return; }
            runAsync("apply:"+d+":"+u);
        });
        stop.setOnClickListener(v -> runAsync("stop"));
    }
    EditText field(String hint) {
        EditText e = new EditText(this); e.setSingleLine(true); e.setHint(hint); e.setHintTextColor(Color.GRAY); e.setTextColor(Color.WHITE);
        e.setInputType(2); e.setPadding(14,8,14,8); return e;
    }
    Button button(String s) {
        Button b = new Button(this); b.setText(s); LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,6,0,6); b.setLayoutParams(p); return b;
    }
    boolean valid(String s) { try { int n=Integer.parseInt(s); return n>=1 && n<=1000; } catch(Exception e) { return false; } }
    void runAsync(String action) {
        status.setText("状态：执行中，请在 Root 弹窗中授权");
        executor.execute(() -> {
            String cmd = buildCommand(action);
            String result = rootExec(cmd);
            runOnUiThread(() -> { log.setText(result); status.setText(result.contains("ROOT_OK") ? "状态：命令已执行；请查看日志验证" : "状态：执行失败或功能不受支持"); });
        });
    }
    String buildCommand(String action) {
        String common = "PATH=/system/bin:/system/xbin:/vendor/bin:/product/bin:$PATH; ";
        String detect = "IFACE=''; for n in /sys/class/net/wlan*; do [ -e \"$n\" ] && IFACE=$(basename \"$n\") && break; done; ";
        if (action.equals("check")) return common+detect+
            "echo ROOT_OK; echo '--- interface ---'; echo \"$IFACE\"; echo '--- tools ---'; command -v tc || true; command -v ip || true; echo '--- kernel qdisc ---'; cat /proc/net/psched 2>/dev/null; echo '--- supported qdisc ---'; (tc qdisc help 2>&1 | head -30) 2>/dev/null";
        if (action.equals("stop")) return common+detect+
            "command -v tc >/dev/null 2>&1 || { echo 'ROOT_OK but tc command missing'; exit 0; }; " +
            "[ -n \"$IFACE\" ] || { echo 'ROOT_OK but Wi-Fi interface not found'; exit 0; }; " +
            "tc qdisc del dev \"$IFACE\" root 2>&1; tc qdisc del dev \"$IFACE\" ingress 2>&1; " +
            "if [ -e /sys/class/net/ifb0 ]; then tc qdisc del dev ifb0 root 2>&1; ip link set ifb0 down 2>&1; ip link del ifb0 type ifb 2>&1; fi; echo 'ROOT_OK'; echo '清理命令已执行（原有 qdisc 可能也被清除）'";
        String[] parts=action.split(":"); String d=parts[1], u=parts[2];
        return common+detect+
            "echo ROOT_OK; command -v tc >/dev/null 2>&1 || { echo 'ERROR: 找不到 tc；需要提供与设备架构匹配的 tc'; exit 0; }; " +
            "[ -n \"$IFACE\" ] || { echo 'ERROR: 找不到 wlan 接口'; exit 0; }; " +
            "echo \"Wi-Fi interface=$IFACE\"; " +
            "tc qdisc replace dev \"$IFACE\" root tbf rate "+u+"mbit burst 256kb latency 100ms 2>&1 || { echo '上传限速失败：内核可能不支持 tbf'; exit 0; }; " +
            "if command -v ip >/dev/null 2>&1 && ip link add ifb0 type ifb 2>/dev/null; then " +
            "ip link set ifb0 up 2>&1; tc qdisc replace dev \"$IFACE\" handle ffff: ingress 2>&1; " +
            "tc filter replace dev \"$IFACE\" parent ffff: protocol all u32 match u32 0 0 action mirred egress redirect dev ifb0 2>&1; " +
            "tc qdisc replace dev ifb0 root tbf rate "+d+"mbit burst 256kb latency 100ms 2>&1; " +
            "else echo '下载限速未启用：内核/系统可能不支持 IFB 或 ip link'; fi; " +
            "echo '--- current qdisc ---'; tc qdisc show dev \"$IFACE\" 2>&1; tc qdisc show dev ifb0 2>&1; echo '完成：数值单位 Mbps；下载入站重定向是否生效需实测'";
    }
    String rootExec(String cmd) {
        StringBuilder out = new StringBuilder();
        try {
            Process p = new ProcessBuilder("su","-c",cmd).redirectErrorStream(true).start();
            BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line; while((line=r.readLine())!=null) out.append(line).append('\n');
            int code=p.waitFor(); out.append("\nexit=").append(code);
        } catch(Exception e) { out.append("执行异常：").append(e); }
        return out.toString();
    }
    @Override protected void onDestroy() { super.onDestroy(); executor.shutdownNow(); }
}
