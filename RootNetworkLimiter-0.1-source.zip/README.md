# Root 网络限速 0.1（实验版）

## 当前实现
- Android 原生 Java 界面，可填写 Wi-Fi 下载/上传限速（Mbps）。
- 使用 `su -c` 执行固定模板的 `tc`/`ip` 命令。
- 上传：尝试对第一个 `wlan*` 接口设置 TBF。
- 下载：尝试 IFB + ingress redirect + TBF。
- 检查：查看 Root、Wi-Fi 接口、tc/ip 命令。
- GitHub Actions 可构建 debug APK。

## 重要限制
1. 这是实验版，不保证所有 Android 内核可用。手机内核必须支持 `tc`、TBF、IFB、mirred/u32 等；系统中还需存在 `tc` 与 `ip`。KernelSU Root 本身不自动提供这些工具或内核功能。
2. 不同手机 Wi-Fi 接口名、内核配置、厂商网络栈不同。下载限速尤其依赖 IFB 入站重定向；如果日志显示失败，不能认为下载已被限速。
3. “清除限速”会删除 Wi-Fi 接口的 root/ingress qdisc，可能影响此前由其他工具设置的 qdisc。不要在已运行其他网络整形规则时盲目使用。
4. 此版本不自动开机应用、不持久化规则、不保证切换 Wi-Fi/移动网络后继续生效，也没有内置 tc 二进制。
5. 数值单位 Mbps；例如 20 Mbps 约等于 2.5 MB/s。若下载本身是 100 Mbps，建议先试下载 60–80 Mbps，为其他 App 留出余量。

## 用手机构建 APK
1. 在 GitHub 新建仓库，例如 `root-network-limiter`。
2. 上传此 ZIP 解压后的所有文件（包括隐藏的 `.github` 目录）到仓库根目录。
3. 打开仓库 Actions，运行 `Build Android APK`。
4. 构建完成后打开该次运行页面，在 Artifacts 下载 `RootNetworkLimiter-debug-apk`，解压得到 `app-debug.apk` 并安装。
5. 首次打开点“检查 Root / tc / Wi-Fi 接口”，在 KernelSU 弹窗中授予 Root。阅读日志确认工具存在后再应用限速。

## 下一步
若 `tc` 不存在，需要针对设备架构（arm64-v8a 等）集成可信来源的静态 tc/ip 二进制；若内核没有 IFB/mirred/u32，则需改用支持的内核方案，或优先在路由器侧做 SQM。
